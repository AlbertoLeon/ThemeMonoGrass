So, you're about to create a footer art for the GNOME Website! Thank you very 
much for this! These are the guidelines on how to create your own awesome footer
art:

- Use drawings based on silhouette, one color based (light gray #d3d7cf).
- Use transparent background with PNG alpha channels
- Image size is 940x180 pixels. Don't forget that ;)
- Putting a fancy animal in the footer art is a plus
- Inkscape is awesome for this kind of work

After that, set a custom field named "footer_art" right on the custom fields of
wordpress pages with the name of the file without the extension. For example:

{"footer_art" : "community"}

Sweden hugs from Brazil,

-- Vinicius Depizzol
vdepizzol@gmail.com
